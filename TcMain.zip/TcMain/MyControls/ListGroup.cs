﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TcMain.MyControls
{
    public partial class ListGroup : UserControl
    {
        private BindingList<TestGroup> _testGroup;
        private List<ItemGroup> itemGroups = new List<ItemGroup>();
        public ListGroup()
        {
            InitializeComponent();
        }

        public void Data(BindingList<TestGroup> testGroups)
        {
            plMain.Controls.Clear();
            foreach (var group in testGroups)
            {
                ItemGroup itemGroup = new ItemGroup();
                itemGroup.Dock = DockStyle.Top;
                itemGroup.Data(group);
                itemGroup.CollapsedStateChanged += ItemGroup_CollapsedStateChangedHandler;
                itemGroups.Add(itemGroup);
               
            }
           itemGroups.Reverse();
            plMain.Controls.AddRange(itemGroups.ToArray());
        }

        public void RefreshAll()
        {
            foreach (var itemGroup in itemGroups)
            {
                itemGroup.Refresh();
            }
        }
        //private void RefreshLayout()
        //{
        //    plMain.SuspendLayout();
        //    foreach (Control control in plMain.Controls)
        //    {
        //        if (control is ItemGroup itemGroup)
        //        {
        //            itemGroup.Refresh();
        //        }
        //    }
        //    plMain.ResumeLayout();
        //}

        private void ItemGroup_CollapsedStateChangedHandler(object? sender, EventArgs e)
        {
            //plMain.SuspendLayout();
            //plMain.ResumeLayout();
        }
    }
}
