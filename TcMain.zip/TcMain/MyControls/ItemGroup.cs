﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TcMain.MyControls
{
    public partial class ItemGroup : UserControl
    {
        private bool _isCollapsed = true;

        // Event to notify parent when collapsed state changes
        public event EventHandler CollapsedStateChanged;

        public ItemGroup()
        {
            InitializeComponent();
            dgvItems.DataBindingComplete += (s, e) => AdjustHeight();
            Init();
        }
        private void Init()
        {
            Collapse();
        }

        private void Collapse()
        {
            dgvItems.Visible = !_isCollapsed;
            iconPictureBox1.IconChar = _isCollapsed ? IconChar.CircleChevronDown : IconChar.CircleChevronUp;
            AdjustHeight();
            // Notify parent to re-render layout
            CollapsedStateChanged?.Invoke(this, EventArgs.Empty);
        }

        public void RefreshAll()
        {
            dgvItems.Refresh();
        }

        private void AdjustHeight()
        {
            int titleHeight = lbTitle.Height;
            int dgvHeight = dgvItems.ColumnHeadersVisible ? dgvItems.ColumnHeadersHeight : 0;
            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (!row.IsNewRow)
                    dgvHeight += row.Height;
            }
            int panelHeight = panel4?.Height ?? 0;
            if (_isCollapsed)
            {
                this.Height = panelHeight;
            }
            else
            {
                this.Height = dgvHeight + panelHeight;
            }
        }

        public void Data(TestGroup testGroup)
        {
            //lbTitle.Text = testGroup.GroupName;
            //lbResult.Text = testGroup.IsPass.Value?"PASS":"FAIL";
            //dgvItems.DataSource = testGroup.TestItems;

            lbTitle.DataBindings.Clear();
            lbResult.DataBindings.Clear();
            dgvItems.DataSource = null;
            lbTitle.DataBindings.Add("Text", testGroup, "GroupName");
            var binding = new Binding("Text", testGroup, "IsPass", true, DataSourceUpdateMode.OnPropertyChanged);
            binding.Format += (s, e) =>
            {
                if (e.Value == null)
                    e.Value = "N/A";
                else
                    e.Value = (bool)e.Value ? "PASS" : "FAIL";
            };
            lbResult.DataBindings.Add(binding);

            dgvItems.DataSource = testGroup.TestItems;
        }

        private void iconPictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            _isCollapsed = !_isCollapsed;
            Collapse();
        }

        private void iconPictureBox1_MouseHover(object sender, EventArgs e)
        {
            iconPictureBox1.ForeColor = SystemColors.GradientActiveCaption;
        }

        private void iconPictureBox1_MouseLeave(object sender, EventArgs e)
        {
            iconPictureBox1.ForeColor = SystemColors.Highlight;
        }

    }
}
