﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TcMain.Models
{
    public class PluginA : IPlugin
    {
        public string Name => "Plugin A";

        public void Run()
        {
            MessageBox.Show("Plugin A is running!");
        }
    }
}
