﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.ComponentModel;

namespace TcMain
{
    //    public class TestGroup
    //{
    //    public string GroupName { get; set; } = string.Empty;
    //    public bool? IsPass { get; set; } = true;
    //    public DateTime? EndTime { get; set; }
    //    public List<TestItem> TestItems { get; set; } = new List<TestItem>();
    //}
    //public class TestItem
    //{

    //    public string Name { get; set; } = string.Empty;
    //    public string Input { get; set; } = string.Empty;
    //    public string ExpectedOutput { get; set; } = string.Empty;
    //    public bool? IsPass { get; set; }
    //}
    public class TestGroup : INotifyPropertyChanged
    {
        private string groupName = string.Empty;
        private bool? isPass = true;
        private DateTime? endTime;

        public string GroupName
        {
            get => groupName;
            set { groupName = value; OnPropertyChanged(nameof(GroupName)); }
        }

        public bool? IsPass
        {
            get => isPass;
            set { isPass = value; OnPropertyChanged(nameof(IsPass)); }
        }
        public TestGroup()
        {
            TestItems.ListChanged += (s, e) => RecalcIsPass();
        }

        private void RecalcIsPass()
        {
            if (TestItems.Count == 0)
            {
                IsPass = null;
            }
            else
            {
                IsPass = TestItems.All(x => x.IsPass == true);
            }
        }


        public DateTime? EndTime
        {
            get => endTime;
            set { endTime = value; OnPropertyChanged(nameof(EndTime)); }
        }

        // Đây là BindingList để DataGridView tự động update
        public BindingList<TestItem> TestItems { get; set; } = new BindingList<TestItem>();

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public class TestItem : INotifyPropertyChanged
    {
        private string name = string.Empty;
        private string input = string.Empty;
        private string expectedOutput = string.Empty;
        private bool? isPass;

        public string Name
        {
            get => name;
            set { name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string Input
        {
            get => input;
            set { input = value; OnPropertyChanged(nameof(Input)); }
        }
        public string ExpectedOutput
        {
            get => expectedOutput;
            set { expectedOutput = value; OnPropertyChanged(nameof(ExpectedOutput)); }
        }
        public bool? IsPass
        {
            get => isPass;
            set { isPass = value; OnPropertyChanged(nameof(IsPass)); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}

