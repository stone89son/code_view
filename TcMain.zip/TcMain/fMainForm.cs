﻿using System.ComponentModel;
using System.Windows.Forms;
using TcMain.Models;
using TcMain.MyControls;

namespace TcMain
{
    public partial class fMainForm : Form
    {
        private BindingList<TestGroup> _testGroup;
        public fMainForm()
        {
            InitializeComponent();
            _testGroup=new BindingList<TestGroup>();
            _testGroup.Add(new TestGroup
            {
                GroupName = "Nhóm 1",
                IsPass = false,
                EndTime = DateTime.Now,
                TestItems = new BindingList<TestItem>
                {
                    new TestItem { Name = "Test 1_2", Input = "Input 1", ExpectedOutput = "Output 1", IsPass = false },
                    new TestItem { Name = "Test 2", Input = "Input 2", ExpectedOutput = "Output 2", IsPass = false }
                }
            });
            _testGroup.Add(new TestGroup
            {
                GroupName = "Nhóm 2",
                IsPass = false,
                EndTime = DateTime.Now,
                TestItems = new BindingList<TestItem>
                {
                    new TestItem { Name = "Test 1", Input = "Input 1", ExpectedOutput = "Output 1", IsPass = false },
                    new TestItem { Name = "Test 2", Input = "Input 2", ExpectedOutput = "Output 2", IsPass = false }
                }
            });
            _testGroup.Add(new TestGroup
            {
                GroupName = "Nhóm 3",
                IsPass = false,
                EndTime = DateTime.Now,
                TestItems = new BindingList<TestItem>
                {
                    new TestItem { Name = "Test 1", Input = "Input 1", ExpectedOutput = "Output 1", IsPass = false },
                    new TestItem { Name = "Test 2", Input = "Input 2", ExpectedOutput = "Output 2", IsPass = false }
                }
            });

            // Assuming you have a DataGridView named dgvTestItems on your form
            listGroup1.Data(_testGroup);
        }

        private void AddTestCase(string header, List<(string cmd, string write, string read, string time)> details)
        {
            // Panel chứa cả header + grid
            Panel casePanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 500,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Header
            Label lblHeader = new Label
            {
                Text = header,
                Dock = DockStyle.Top,
                Height = 30,
                BackColor = Color.DarkViolet,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(5, 0, 0, 0)
            };
            casePanel.Controls.Add(lblHeader);

            // GridView
            DataGridView dgv = new DataGridView
            {
                //Margin = new Padding(30, 30, 0, 0),
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                Height = 300,
                AllowUserToAddRows = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing
            };

            dgv.Columns.Add("cmd", "Command");
            dgv.Columns.Add("write", "Giá trị ghi");
            dgv.Columns.Add("read", "Giá trị đọc");
            dgv.Columns.Add("time", "Thời gian");

            foreach (var d in details)
            {
                dgv.Rows.Add(d.cmd, d.write, d.read, d.time);
            }

            casePanel.Controls.Add(dgv);

            // Thêm panel này vào form (ví dụ 1 FlowLayoutPanel để auto sắp xếp)
            panel1.Controls.Add(casePanel);
        }

        // Step 3: Update IsPass and UI will refresh automatically
        private void button1_Click(object sender, EventArgs e)
        {
            var group1= _testGroup.First();
            var testItems = group1.TestItems;
            if (testItems != null)
            {
                foreach (var testItem in testItems) {
                    testItem.ExpectedOutput = "dddddddddd";
                    testItem.IsPass = true;
                }
                 
            }
            group1.IsPass = true;
            // listGroup1.RefreshAll();
        }
    }
}
