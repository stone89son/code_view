﻿using System.ComponentModel;
using System.Windows.Forms;
using TcMain.Models;
using TcMain.MyControls;

namespace TcMain
{
    public partial class fMainForm : Form
    {
        private List<TestItem> _testItems;
        public fMainForm()
        {
            InitializeComponent();

            _testItems = new List<TestItem>
            {
                new TestItem { GroupName = "Nhóm 1", Name = "Test 1_2", Input = "Input 1", ExpectedOutput = "Output 1", IsPass = false },
                new TestItem { GroupName = "Nhóm 1", Name = "Test 2", Input = "Input 2", ExpectedOutput = "Output 2", IsPass = false },
                new TestItem { GroupName = "Nhóm 2", Name = "Test 1", Input = "Input 1", ExpectedOutput = "Output 1", IsPass = false },
                new TestItem { GroupName = "Nhóm 2", Name = "Test 2", Input = "Input 2", ExpectedOutput = "Output 2", IsPass = false }
            };

            for (int i = 0; i < 10; i++)
            {
                _testItems.Add(new TestItem
                {
                    GroupName = "Nhóm " + (i + 1),
                    Name = "Test 1_23" + i,
                    Input = "Input 1",
                    ExpectedOutput = "Output 1",
                    IsPass = false
                });
            }
            // Assuming you have a DataGridView named dgvTestItems on your form
            listGroup1.Data(_testItems);
        }

        private void AddTestCase(string header, List<(string cmd, string write, string read, string time)> details)
        {
            // Panel chứa cả header + grid
            Panel casePanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 500,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Header
            Label lblHeader = new Label
            {
                Text = header,
                Dock = DockStyle.Top,
                Height = 30,
                BackColor = Color.DarkViolet,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(5, 0, 0, 0)
            };
            casePanel.Controls.Add(lblHeader);

            // GridView
            DataGridView dgv = new DataGridView
            {
                //Margin = new Padding(30, 30, 0, 0),
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                Height = 300,
                AllowUserToAddRows = false,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing
            };

            dgv.Columns.Add("cmd", "Command");
            dgv.Columns.Add("write", "Giá trị ghi");
            dgv.Columns.Add("read", "Giá trị đọc");
            dgv.Columns.Add("time", "Thời gian");

            foreach (var d in details)
            {
                dgv.Rows.Add(d.cmd, d.write, d.read, d.time);
            }

            casePanel.Controls.Add(dgv);

            // Thêm panel này vào form (ví dụ 1 FlowLayoutPanel để auto sắp xếp)
            panel1.Controls.Add(casePanel);
        }

        // Step 3: Update IsPass and UI will refresh automatically
        private void button1_Click(object sender, EventArgs e)
        {
            var testItem = _testItems.FirstOrDefault(e => e.Name == "Test 1_2");
            if (testItem != null)
            {
                testItem.ExpectedOutput = "dddddddddd";
                testItem.IsPass = true;
            }

            listGroup1.RefreshAll();
        }
    }
}
